"""
Stripe Checkout module — wrapper around stripe.checkout.Session.

Compatible with the API expected by server.py.
"""

import stripe
import logging
from typing import Optional, Dict, Any, List
from dataclasses import dataclass, field, asdict

logger = logging.getLogger(__name__)


@dataclass
class CheckoutSessionRequest:
    """Request to create a Stripe checkout session."""
    amount: float
    currency: str
    success_url: str
    cancel_url: str
    metadata: Dict[str, str] = field(default_factory=dict)


@dataclass
class CheckoutSessionResponse:
    """Response from creating a checkout session."""
    session_id: str
    url: str
    amount_total: float
    currency: str


@dataclass
class CheckoutStatusResponse:
    """Response from checking checkout session status."""
    status: str
    payment_status: str
    amount_total: Optional[float] = None
    currency: Optional[str] = None


@dataclass
class WebhookResponse:
    """Parsed webhook response."""
    payment_status: str
    metadata: Dict[str, str] = field(default_factory=dict)


class StripeCheckout:
    """Wrapper around Stripe Checkout Sessions."""

    def __init__(self, api_key: str, webhook_url: str):
        self.api_key = api_key
        self.webhook_url = webhook_url
        stripe.api_key = api_key

    async def create_checkout_session(
        self, req: CheckoutSessionRequest
    ) -> CheckoutSessionResponse:
        """Create a Stripe checkout session."""
        amount_cents = int(round(req.amount * 100))
        
        try:
            session = stripe.checkout.Session.create(
                line_items=[{
                    "price_data": {
                        "currency": req.currency,
                        "product_data": {
                            "name": "Pack 7 Jours — Human Matrix",
                            "description": "Protocole de restauration humaine en 7 jours",
                        },
                        "unit_amount": amount_cents,
                    },
                    "quantity": 1,
                }],
                mode="payment",
                success_url=req.success_url,
                cancel_url=req.cancel_url,
                metadata=req.metadata,
                payment_intent_data={
                    "metadata": req.metadata,
                },
            )
            
            logger.info(f"Stripe session created: {session.id}")
            
            return CheckoutSessionResponse(
                session_id=session.id,
                url=session.url,
                amount_total=float(session.amount_total or amount_cents) / 100,
                currency=session.currency or req.currency,
            )
        except Exception as e:
            logger.error(f"Failed to create Stripe session: {e}")
            raise

    async def get_checkout_status(self, session_id: str) -> CheckoutStatusResponse:
        """Check the status of a checkout session."""
        try:
            session = stripe.checkout.Session.retrieve(session_id)
            
            amount_total = None
            if session.amount_total:
                amount_total = session.amount_total / 100.0
            
            return CheckoutStatusResponse(
                status=session.status or "unknown",
                payment_status=session.payment_status or "unpaid",
                amount_total=amount_total,
                currency=session.currency,
            )
        except Exception as e:
            logger.error(f"Failed to get checkout status: {e}")
            raise

    async def handle_webhook(
        self, body: bytes, signature: Optional[str]
    ) -> WebhookResponse:
        """Handle Stripe webhook event."""
        if not signature:
            logger.warning("No Stripe signature provided")
            return WebhookResponse(payment_status="unknown")
        
        try:
            endpoint_secret = stripe.WebhookEndpoint.list().data[-1].secret if stripe.WebhookEndpoint.list().data else None
            
            if endpoint_secret:
                event = stripe.Webhook.construct_event(
                    payload=body, sig_header=signature, secret=endpoint_secret
                )
            else:
                # Fallback: just parse the event without verification
                event_data = stripe.Event.construct_from(
                    stripe.util.json.loads(body), stripe.api_key
                )
                event = event_data
            
            if event.type == "checkout.session.completed":
                session = event.data.object
                payment_status = session.get("payment_status", "paid")
                metadata = session.get("metadata", {})
                return WebhookResponse(
                    payment_status=payment_status,
                    metadata=metadata,
                )
            
            return WebhookResponse(payment_status="unknown")
            
        except Exception as e:
            logger.error(f"Webhook handling error: {e}")
            return WebhookResponse(payment_status="error")
