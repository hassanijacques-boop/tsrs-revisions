"""
Stripe checkout wrapper for Human Matrix.
Uses stripe library directly.
"""
