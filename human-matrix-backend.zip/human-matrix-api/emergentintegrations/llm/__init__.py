"""
LLM chat wrapper for Human Matrix.
Uses OpenAI library directly.
"""
