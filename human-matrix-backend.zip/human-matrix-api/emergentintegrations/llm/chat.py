"""
LLM Chat module — wrapper around OpenAI-compatible chat APIs.

Supports OpenAI and any OpenAI-compatible endpoint.
Compatible with the API expected by server.py.
"""

import json
import logging
from typing import Optional, Dict, Any
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass
class UserMessage:
    """A user message in the chat."""
    text: str


class LlmChat:
    """Wrapper around LLM chat APIs (OpenAI-compatible)."""

    def __init__(
        self,
        api_key: str,
        session_id: str,
        system_message: str,
        model: str = "gpt-4o-mini",
        provider: str = "openai",
    ):
        self.api_key = api_key
        self.session_id = session_id
        self.system_message = system_message
        self.model = model
        self.provider = provider
        self.messages: list = []
        
        if system_message:
            self.messages.append({"role": "system", "content": system_message})

    def with_model(self, provider: str, model: str) -> "LlmChat":
        """Set the model to use."""
        self.provider = provider
        self.model = model
        return self

    async def send_message(self, user_message: UserMessage) -> str:
        """Send a message and get the response."""
        from openai import AsyncOpenAI
        
        self.messages.append({"role": "user", "content": user_message.text})
        
        # Determine base URL
        base_url = None
        if self.provider == "openai":
            client = AsyncOpenAI(api_key=self.api_key)
        elif self.provider == "anthropic":
            # Use OpenAI-compatible endpoint for Anthropic via OpenRouter
            client = AsyncOpenAI(
                api_key=self.api_key,
                base_url="https://api.openai.com/v1",  # fallback
            )
        else:
            client = AsyncOpenAI(
                api_key=self.api_key,
                base_url=f"https://api.{self.provider}.com/v1",
            )
        
        try:
            response = await client.chat.completions.create(
                model=self.model,
                messages=self.messages,
                temperature=0.7,
                max_tokens=2000,
            )
            
            content = response.choices[0].message.content or ""
            self.messages.append({"role": "assistant", "content": content})
            
            return content
            
        except Exception as e:
            logger.error(f"LLM API error: {e}")
            
            # Fallback: try with base provider if custom failed
            if self.provider != "openai":
                try:
                    logger.info("Falling back to OpenAI")
                    client = AsyncOpenAI(api_key=self.api_key)
                    response = await client.chat.completions.create(
                        model="gpt-4o-mini",
                        messages=self.messages,
                        temperature=0.7,
                        max_tokens=2000,
                    )
                    content = response.choices[0].message.content or ""
                    self.messages.append({"role": "assistant", "content": content})
                    return content
                except Exception as e2:
                    logger.error(f"Fallback LLM also failed: {e2}")
            
            # Return fallback JSON if all fails
            fallback = json.dumps({
                "missions": [
                    {"pole": "Djism", "title": "Marche consciente", "description": "Marche 20 minutes dehors sans téléphone.", "duration_minutes": 20},
                    {"pole": "Aql", "title": "Focus sans distraction", "description": "Travaille 25 min sur ta priorité. Pas de notifications.", "duration_minutes": 25},
                    {"pole": "Nafs", "title": "Résiste à une tentation", "description": "Identifie une tentation et résiste-y aujourd'hui.", "duration_minutes": 15},
                    {"pole": "Qalb", "title": "Moment de gratitude", "description": "Écris 3 choses pour lesquelles tu es reconnaissant.", "duration_minutes": 10},
                ]
            })
            return fallback
