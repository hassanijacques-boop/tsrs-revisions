/* Altius Explicite service worker
 * Strategy:
 * - precache: app shell (index.html + manifest + icons)
 * - runtime: stale-while-revalidate for static JS/CSS chunks
 * - runtime: network-first for /api with offline fallback to cache for GETs
 * - never cache POST/PUT/DELETE
 */

const CACHE_PREFIX = "altius-v3";
const APP_SHELL_CACHE = `${CACHE_PREFIX}-shell`;
const RUNTIME_CACHE = `${CACHE_PREFIX}-runtime`;
const API_CACHE = `${CACHE_PREFIX}-api`;

const APP_SHELL = [
  "/",
  "/manifest.json",
  "/altius-icon-192.svg",
  "/altius-icon-512.svg",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(APP_SHELL_CACHE).then((cache) => cache.addAll(APP_SHELL)).catch(() => null)
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys
          .filter((k) => k.startsWith("altius-") && !k.startsWith(CACHE_PREFIX))
          .map((k) => caches.delete(k))
      )
    )
  );
  self.clients.claim();
});

function isApiRequest(url) {
  return url.pathname.startsWith("/api/");
}

// Stale-while-revalidate for static assets
async function staleWhileRevalidate(request) {
  const cache = await caches.open(RUNTIME_CACHE);
  const cached = await cache.match(request);
  const fetchPromise = fetch(request)
    .then((response) => {
      if (response && response.status === 200 && response.type === "basic") {
        cache.put(request, response.clone());
      }
      return response;
    })
    .catch(() => null);
  return cached || (await fetchPromise) || new Response("Hors-ligne", { status: 503 });
}

// Network-first for navigation
async function networkFirstHTML(request) {
  try {
    const fresh = await fetch(request);
    const cache = await caches.open(APP_SHELL_CACHE);
    cache.put("/", fresh.clone()).catch(() => null);
    return fresh;
  } catch {
    const cache = await caches.open(APP_SHELL_CACHE);
    const cached = await cache.match("/");
    return cached || new Response("Hors-ligne", { status: 503 });
  }
}

// Network-first for API GETs, with cache fallback
async function networkFirstAPI(request) {
  try {
    const fresh = await fetch(request);
    if (fresh && fresh.status === 200) {
      const cache = await caches.open(API_CACHE);
      cache.put(request, fresh.clone()).catch(() => null);
    }
    return fresh;
  } catch {
    const cache = await caches.open(API_CACHE);
    const cached = await cache.match(request);
    if (cached) return cached;
    return new Response(JSON.stringify({ offline: true, detail: "Mode hors-ligne" }), {
      status: 503,
      headers: { "Content-Type": "application/json" },
    });
  }
}

self.addEventListener("fetch", (event) => {
  const { request } = event;
  if (request.method !== "GET") return; // never cache mutations
  const url = new URL(request.url);

  // 1) API (only same-origin GETs)
  if (isApiRequest(url) && url.origin === self.location.origin) {
    event.respondWith(networkFirstAPI(request));
    return;
  }

  // 2) Navigation (HTML)
  if (request.mode === "navigate") {
    event.respondWith(networkFirstHTML(request));
    return;
  }

  // 3) Static assets (same-origin)
  if (url.origin === self.location.origin) {
    event.respondWith(staleWhileRevalidate(request));
    return;
  }
});

// Message channel for cache busting from app
self.addEventListener("message", (event) => {
  if (event.data === "skip-waiting") self.skipWaiting();
});
